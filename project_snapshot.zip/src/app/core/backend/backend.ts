import { DestroyRef, Service, inject } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import type {
	AppEvent,
	AudioOutputDevice,
	LibraryAlbumArtistPage,
	LibraryAlbumArtistKey,
	LibraryAlbumArtistSortKey,
	LibraryAlbumArtistSummary,
	LibraryAlbumDetails,
	LibraryAlbumKey,
	LibraryAlbumPage,
	LibraryAlbumSortKey,
	LibraryAlbumTrackPage,
	LibraryArtistAlbumSortKey,
	LibrarySortDirection,
	LibraryRoot,
	LibraryScanSnapshot,
	LibraryStatus,
	LibraryTrackPage,
	LibraryTrackSortKey,
	LibraryTrackSummary,
	NativeAppApi,
	PlaybackQueue,
	PlaybackState
} from '@shared/native-app-api';

@Service()
export class Backend {
	private readonly api: NativeAppApi | null = window.nativeApp ?? null;
	private readonly eventSubject = new Subject<AppEvent>();
	private readonly destroyRef = inject(DestroyRef);

	readonly available = this.api !== null;
	readonly events: Observable<AppEvent> = this.eventSubject.asObservable();

	constructor() {
		const unsubscribe = this.api?.onEvent((event) => this.eventSubject.next(event));
		this.destroyRef.onDestroy(() => unsubscribe?.());
	}

	getPlaybackState(): Promise<PlaybackState> {
		return this.requireApi().getPlaybackState();
	}
	getPlaybackQueue(): Promise<PlaybackQueue> {
		return this.requireApi().getPlaybackQueue();
	}
	pausePlayback(): Promise<PlaybackState> {
		return this.requireApi().pausePlayback();
	}
	resumePlayback(): Promise<PlaybackState> {
		return this.requireApi().resumePlayback();
	}
	previousPlayback(): Promise<PlaybackState> {
		return this.requireApi().previousPlayback();
	}
	nextPlayback(): Promise<PlaybackState> {
		return this.requireApi().nextPlayback();
	}
	seekPlayback(positionMs: number): Promise<PlaybackState> {
		return this.requireApi().seekPlayback(positionMs);
	}
	setPlaybackVolume(volume: number): Promise<PlaybackState> {
		return this.requireApi().setPlaybackVolume(volume);
	}
	setPlaybackMuted(muted: boolean): Promise<PlaybackState> {
		return this.requireApi().setPlaybackMuted(muted);
	}
	listAudioOutputDevices(): Promise<AudioOutputDevice[]> {
		return this.requireApi().listAudioOutputDevices();
	}
	selectLibraryDirectory(): Promise<string | null> {
		return this.requireApi().selectLibraryDirectory();
	}
	getLibraryStatus(): Promise<LibraryStatus> {
		return this.requireApi().getLibraryStatus();
	}
	listLibraryRoots(): Promise<LibraryRoot[]> {
		return this.requireApi().listLibraryRoots();
	}
	registerLibraryRoot(path: string): Promise<LibraryRoot> {
		return this.requireApi().registerLibraryRoot(path);
	}
	setLibraryRootEnabled(id: string, enabled: boolean): Promise<LibraryRoot> {
		return this.requireApi().setLibraryRootEnabled(id, enabled);
	}
	removeLibraryRoot(id: string): Promise<void> {
		return this.requireApi().removeLibraryRoot(id);
	}
	getLibraryScanState(): Promise<LibraryScanSnapshot> {
		return this.requireApi().getLibraryScanState();
	}
	startLibraryScan(): Promise<void> {
		return this.requireApi().startLibraryScan();
	}
	cancelLibraryScan(): Promise<void> {
		return this.requireApi().cancelLibraryScan();
	}
	listLibraryTracks(
		cursor: string | null,
		search: string | null,
		sortKey: LibraryTrackSortKey,
		sortDirection: LibrarySortDirection
	): Promise<LibraryTrackPage> {
		return this.requireApi().listLibraryTracks(cursor, search, sortKey, sortDirection);
	}
	listLibraryAlbums(
		cursor: string | null,
		search: string | null,
		sortKey: LibraryAlbumSortKey,
		sortDirection: LibrarySortDirection
	): Promise<LibraryAlbumPage> {
		return this.requireApi().listLibraryAlbums(cursor, search, sortKey, sortDirection);
	}
	listLibraryAlbumArtists(
		cursor: string | null,
		search: string | null,
		sortKey: LibraryAlbumArtistSortKey,
		sortDirection: LibrarySortDirection
	): Promise<LibraryAlbumArtistPage> {
		return this.requireApi().listLibraryAlbumArtists(cursor, search, sortKey, sortDirection);
	}
	getLibraryAlbumArtist(artistKey: LibraryAlbumArtistKey): Promise<LibraryAlbumArtistSummary> {
		return this.requireApi().getLibraryAlbumArtist(artistKey);
	}
	listLibraryArtistAlbums(
		artistKey: LibraryAlbumArtistKey,
		cursor: string | null,
		sortKey: LibraryArtistAlbumSortKey,
		sortDirection: LibrarySortDirection
	): Promise<LibraryAlbumPage> {
		return this.requireApi().listLibraryArtistAlbums(artistKey, cursor, sortKey, sortDirection);
	}
	getLibraryAlbumDetails(albumKey: LibraryAlbumKey): Promise<LibraryAlbumDetails> {
		return this.requireApi().getLibraryAlbumDetails(albumKey);
	}
	listLibraryAlbumTracks(
		albumKey: LibraryAlbumKey,
		cursor: string | null
	): Promise<LibraryAlbumTrackPage> {
		return this.requireApi().listLibraryAlbumTracks(albumKey, cursor);
	}
	getLibraryTrackForPath(path: string): Promise<LibraryTrackSummary | null> {
		return this.requireApi().getLibraryTrackForPath(path);
	}
	startLibraryTrack(trackId: string): Promise<PlaybackState> {
		return this.requireApi().startLibraryTrack(trackId);
	}
	startLibraryAlbum(albumKey: LibraryAlbumKey): Promise<PlaybackState> {
		return this.requireApi().startLibraryAlbum(albumKey);
	}

	private requireApi(): NativeAppApi {
		if (!this.api) throw new Error('Native application API is unavailable.');
		return this.api;
	}
}
