import type { LibraryAlbumKey } from '@shared/native-app-api';

export function requireString(value: unknown, name: string): string {
	if (typeof value !== 'string' || value.length === 0)
		throw new TypeError(`${name} must be a non-empty string`);
	return value;
}

export function requireNullableString(value: unknown, name: string): string | null {
	if (value !== null && typeof value !== 'string')
		throw new TypeError(`${name} must be a string or null`);
	return value;
}

export function requireBoolean(value: unknown, name: string): boolean {
	if (typeof value !== 'boolean') throw new TypeError(`${name} must be a boolean`);
	return value;
}

export function requireOneOf<T extends string>(
	value: unknown,
	name: string,
	values: readonly T[]
): T {
	if (typeof value !== 'string' || !values.includes(value as T))
		throw new TypeError(`${name} must be one of: ${values.join(', ')}`);
	return value as T;
}

export function requireNonNegativeInteger(value: unknown, name: string): number {
	if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < 0)
		throw new TypeError(`${name} must be a non-negative safe integer`);
	return value;
}

export function requireUnitInterval(value: unknown, name: string): number {
	if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > 1)
		throw new TypeError(`${name} must be between 0 and 1`);
	return value;
}

export function requireAlbumKey(value: unknown): LibraryAlbumKey {
	if (
		typeof value !== 'object' ||
		value === null ||
		typeof (value as { title?: unknown }).title !== 'string' ||
		typeof (value as { albumArtist?: unknown }).albumArtist !== 'string'
	)
		throw new TypeError('albumKey must contain title and albumArtist strings');
	return value as LibraryAlbumKey;
}
