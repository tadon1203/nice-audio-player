# Development Pがilosophy

## Document responsibility

This document is the source of truth for the project's development and documentation principles. It does not define product requirements, system architecture, or operational contribution rules.

## Goals

すべて認知負荷の減少に回帰する。

## Design Principles

ファイル構造、コード構造、命名などによって意図を明らかにする。
場当たり的な修正は避け、長期的に一貫し、拡張が容易であるがオーバーエンジニアリングにならないように設計する。
明確な実利的理由なしに、既存コードの変更に対して保守的になるか、変更を望むことは禁止されている。
自然に共通化できる場合のみ、UIコードが重複した場合は共通化を行う。
プロジェクトの文脈は無視しないが、一般的な慣例や標準的な実装を重視する。
標準ライブラリや既存ライブラリがすでに提供している機能を自前で再実装することは、明確な実利的理由がない場合禁止される。

## Documentation

ドキュメントは信頼できる単一の情報源。
木のように、README.mdやAGENTS.mdから分岐させる。
運用コストを減らすために、詳細を書きすぎない。
他ドキュメントに重複する内容を書かない。
